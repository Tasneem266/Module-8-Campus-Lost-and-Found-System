# custom middleware file created.

import time
from django.utils import timezone

class RequestLoggingMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start_time = time.time()
        response = self.get_response(request)
        duration = time.time() - start_time
        
        user = request.user.username if request.user.is_authenticated else 'Anonymous'
        method = request.method
        path = request.path
        
        print(f"User: {user} Method: {method} Path: {path} Time: {duration:.2f} seconds")
        
        return response
