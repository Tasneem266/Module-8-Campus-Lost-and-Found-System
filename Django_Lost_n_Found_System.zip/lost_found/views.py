from django.shortcuts import render, redirect, get_object_or_404            #custom
from django.contrib.auth import login, logout, authenticate           #custom
from django.contrib.auth.decorators import login_required           #custom
from django.contrib import messages           #custom
from django.db.models import Q           #custom
from .models import Report           #custom
from .forms import RegisterForm, ReportForm           #custom

# Create your views here.

def home(request):
    reports = Report.objects.filter(status='active')[:6]
    return render(request, 'home.html', {'reports': reports})

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful! Welcome to Campus Lost & Found.')
            return redirect('home')
        else:
            messages.error(request, 'Registration failed. Please correct the errors.')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {username}!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home')

def report_list(request):
    reports = Report.objects.all()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    category_filter = request.GET.get('category', '')
    type_filter = request.GET.get('type', '')
    
    if search_query:
        reports = reports.filter(
            Q(item_name__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    
    if category_filter:
        reports = reports.filter(category=category_filter)
    
    if type_filter:
        reports = reports.filter(report_type=type_filter)
    
    context = {
        'reports': reports,
        'search_query': search_query,
        'category_filter': category_filter,
        'type_filter': type_filter,
    }
    return render(request, 'report_list.html', context)

def report_detail(request, pk):
    report = get_object_or_404(Report, pk=pk)
    return render(request, 'report_detail.html', {'report': report})

@login_required
def report_create(request):
    if request.method == 'POST':
        form = ReportForm(request.POST, request.FILES)
        if form.is_valid():
            report = form.save(commit=False)
            report.user = request.user
            report.save()
            messages.success(request, 'Report created successfully!')
            return redirect('report_detail', pk=report.pk)
    else:
        form = ReportForm()
    return render(request, 'report_form.html', {'form': form, 'action': 'Create'})

@login_required
def report_edit(request, pk):
    report = get_object_or_404(Report, pk=pk)
    
    # Check if user owns the report
    if report.user != request.user:
        messages.error(request, 'You can only edit your own reports.')
        return redirect('report_list')
    
    if request.method == 'POST':
        form = ReportForm(request.POST, request.FILES, instance=report)
        if form.is_valid():
            form.save()
            messages.success(request, 'Report updated successfully!')
            return redirect('report_detail', pk=report.pk)
    else:
        form = ReportForm(instance=report)
    return render(request, 'report_form.html', {'form': form, 'action': 'Edit'})

@login_required
def report_delete(request, pk):
    report = get_object_or_404(Report, pk=pk)
    
    if report.user != request.user:
        messages.error(request, 'You can only delete your own reports.')
        return redirect('report_list')
    
    if request.method == 'POST':
        report.delete()
        messages.success(request, 'Report deleted successfully!')
        return redirect('report_list')
    
    return render(request, 'report_confirm_delete.html', {'report': report})

@login_required
def my_reports(request):
    reports = Report.objects.filter(user=request.user)
    return render(request, 'my_reports.html', {'reports': reports})

@login_required
def resolve_report(request, pk):
    report = get_object_or_404(Report, pk=pk)
    
    if report.user != request.user:
        messages.error(request, 'You can only resolve your own reports.')
        return redirect('report_list')
    
    if request.method == 'POST':
        report.status = 'resolved'
        report.save()
        messages.success(request, 'Report marked as resolved!')
        return redirect('report_detail', pk=report.pk)
    
    return render(request, 'resolve_confirm.html', {'report': report})

