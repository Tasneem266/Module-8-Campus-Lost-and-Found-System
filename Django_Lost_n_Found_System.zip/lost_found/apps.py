from django.apps import AppConfig


class LostFoundConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'  #custom
    name = 'lost_found'
